let frutas= ["Manzana", "Pera", "Banana"];
let aux= 12*20;


let persona = {
    nombre: "Martin",
    apellido: "Argalas",
    edad: "22",
    equipo: "ford",
    frutas: frutas,
}

let persona1 = {
    nombre: "Martin",
    apellido: "Argalas",
    colores: ["rojo, verde, gris"],
    dni:27498237,
    edad: 22,
}
let persona2= {
    nombre: "Juan",
    apellido: "Peres",
    colores: ["blanco, rosa, azul"],
    dni:297465,
    edad: 30,
}
/*function saludar(){
 console.log("hola mundo");
}
function sumar(valor1, valor2){
    console.log(valor1 + valor2);
}
*/
function mayor (persona1, persona2){
       if (persona1.edad > persona2.edad) {
        console.log(persona1.edad)
       } else {
        console.log(persona2.edad)
       }
        
}
function ganador (persona1, persona2){
    if (persona1.colores == "azul"){
        console.log(persona1.colores)
    } else {
        console.log(persona2.colores)
    }
}

console.log(ganador (persona1,persona2));
console.log(mayor(persona1, persona2));

//console.log(sumar(24,1));
//console.log(saludar ());
//console.log(persona.nombre);
//console.log(persona.apellido);
//console.log(persona.edad);
//console.log(persona.equipo);
//console.log(persona.frutas);

console.log(persona);
//console.log(frutas);
//console.log(aux);

// En esto pones una palabra en minuscula y pasa a mayuscula.
let palabra= "hola mundo";            
(palabra.length);                       
console.log(palabra.toUpperCase());   


// Con estos cuenta los datos osea los colores que declaraste en este caso son 3.
let color=["rojo", "azul", "verde"];
console.log (color.length);

// Con estos comandos se pueden agregar un color al principio y al final ademas de los que ya estan declarados.
let colores1=["rojo", "verde" ];   // estos son los colores q estan declarados 
colores1.unshift("azul");         // esto es el comando para agregar un color al principio
colores1.push("gris");            // esto es para agregar n color al final.
console.log(colores1); 

// Con estos datos tengo que calcular cual tiene mas cantidad sumando primero cada uno de los numeros que hay dentro de la bariable cantidad.
let caja1={ 
    nombre:"pepe",
    color:"rojo",
    peso:40,
    altura:20,
    cantidad:[2, 4, 1],
}

let caja2={ 
    nombre:"lucas",
    color:"verde",
    peso:75,
    altura:90,
    cantidad:[1, 2, 5],
    
}
console.log (caja1,caja2);

// Aca empieza a resolverse el ejercicio.

function sumarCantidad(caja) {
    return caja.cantidad.reduce((sum, valor) => sum + valor, 0);
}

// Sumar las cantidades de cada caja
let sumaCaja1 = sumarCantidad(caja1);
let sumaCaja2 = sumarCantidad(caja2);

// Comparar las sumas y determinar cuál tiene más cantidad
if (sumaCaja1 > sumaCaja2) {
    console.log(`${caja1.nombre} tiene más cantidad con un total de ${sumaCaja1}`);
} else if (sumaCaja2 > sumaCaja1) {
    console.log(`${caja2.nombre} tiene más cantidad con un total de ${sumaCaja2}`);
} else {
    console.log("Ambas cajas tienen la misma cantidad.");
}
//Utilizamos el método reduce para sumar todos los números en el array cantidad de cada caja.
//Luego, comparamos las sumas de caja1 y caja2 y mostramos cuál tiene la suma más alta.


// con los siguientes datos de personajes me tenes que decir el nombre de que personaje aparece en mas episodios.

let personaje1={
    "id": 5,
    "name": "Jerry Smith",
    "status": "Alive",
    "species": "Human",
    "type": "",
    "gender": "Male",
    "origin": {
      "name": "Earth (Replacement Dimension)",
      "url": "https://rickandmortyapi.com/api/location/20"
    },
    "location": {
      "name": "Earth (Replacement Dimension)",
      "url": "https://rickandmortyapi.com/api/location/20"
    },
    "image": "https://rickandmortyapi.com/api/character/avatar/5.jpeg",
    "episode": [
      "https://rickandmortyapi.com/api/episode/6",
      "https://rickandmortyapi.com/api/episode/7",
      "https://rickandmortyapi.com/api/episode/8",
      "https://rickandmortyapi.com/api/episode/9",
      "https://rickandmortyapi.com/api/episode/10",
      "https://rickandmortyapi.com/api/episode/11",
      "https://rickandmortyapi.com/api/episode/12",
      "https://rickandmortyapi.com/api/episode/13",
      "https://rickandmortyapi.com/api/episode/14",
      "https://rickandmortyapi.com/api/episode/15",
      "https://rickandmortyapi.com/api/episode/16",
      "https://rickandmortyapi.com/api/episode/18",
      "https://rickandmortyapi.com/api/episode/19",
      "https://rickandmortyapi.com/api/episode/20",
      "https://rickandmortyapi.com/api/episode/21",
      "https://rickandmortyapi.com/api/episode/22",
      "https://rickandmortyapi.com/api/episode/23",
      "https://rickandmortyapi.com/api/episode/26",
      "https://rickandmortyapi.com/api/episode/29",
      "https://rickandmortyapi.com/api/episode/30",
      "https://rickandmortyapi.com/api/episode/31",
      "https://rickandmortyapi.com/api/episode/32",
      "https://rickandmortyapi.com/api/episode/33",
      "https://rickandmortyapi.com/api/episode/35",
      "https://rickandmortyapi.com/api/episode/36",
      "https://rickandmortyapi.com/api/episode/38",
      "https://rickandmortyapi.com/api/episode/39",
      "https://rickandmortyapi.com/api/episode/40",
      "https://rickandmortyapi.com/api/episode/41",
      "https://rickandmortyapi.com/api/episode/42",
      "https://rickandmortyapi.com/api/episode/43",
      "https://rickandmortyapi.com/api/episode/44",
      "https://rickandmortyapi.com/api/episode/45",
      "https://rickandmortyapi.com/api/episode/46",
      "https://rickandmortyapi.com/api/episode/47",
      "https://rickandmortyapi.com/api/episode/48",
      "https://rickandmortyapi.com/api/episode/49",
      "https://rickandmortyapi.com/api/episode/50",
      "https://rickandmortyapi.com/api/episode/51"
    ],
    "url": "https://rickandmortyapi.com/api/character/5",
    "created": "2017-11-04T19:26:56.301Z"
}

let personaje2={
    "id": 1,
    "name": "Rick Sanchez",
    "status": "Alive",
    "species": "Human",
    "type": "",
    "gender": "Male",
    "origin": {
      "name": "Earth (C-137)",
      "url": "https://rickandmortyapi.com/api/location/1"
    },
    "location": {
      "name": "Citadel of Ricks",
      "url": "https://rickandmortyapi.com/api/location/3"
    },
    "image": "https://rickandmortyapi.com/api/character/avatar/1.jpeg",
    "episode": [
      "https://rickandmortyapi.com/api/episode/1",
      "https://rickandmortyapi.com/api/episode/2",
      "https://rickandmortyapi.com/api/episode/3",
      "https://rickandmortyapi.com/api/episode/4",
      "https://rickandmortyapi.com/api/episode/5",
      "https://rickandmortyapi.com/api/episode/6",
      "https://rickandmortyapi.com/api/episode/7",
      "https://rickandmortyapi.com/api/episode/8",
      "https://rickandmortyapi.com/api/episode/9",
      "https://rickandmortyapi.com/api/episode/10",
      "https://rickandmortyapi.com/api/episode/11",
      "https://rickandmortyapi.com/api/episode/12",
      "https://rickandmortyapi.com/api/episode/13",
      "https://rickandmortyapi.com/api/episode/14",
      "https://rickandmortyapi.com/api/episode/15",
      "https://rickandmortyapi.com/api/episode/16",
      "https://rickandmortyapi.com/api/episode/17",
      "https://rickandmortyapi.com/api/episode/18",
      "https://rickandmortyapi.com/api/episode/19",
      "https://rickandmortyapi.com/api/episode/20",
      "https://rickandmortyapi.com/api/episode/21",
      "https://rickandmortyapi.com/api/episode/22",
      "https://rickandmortyapi.com/api/episode/23",
      "https://rickandmortyapi.com/api/episode/24",
      "https://rickandmortyapi.com/api/episode/25",
      "https://rickandmortyapi.com/api/episode/26",
      "https://rickandmortyapi.com/api/episode/27",
      "https://rickandmortyapi.com/api/episode/28",
      "https://rickandmortyapi.com/api/episode/29",
      "https://rickandmortyapi.com/api/episode/30",
      "https://rickandmortyapi.com/api/episode/31",
      "https://rickandmortyapi.com/api/episode/32",
      "https://rickandmortyapi.com/api/episode/33",
      "https://rickandmortyapi.com/api/episode/34",
      "https://rickandmortyapi.com/api/episode/35",
      "https://rickandmortyapi.com/api/episode/36",
      "https://rickandmortyapi.com/api/episode/37",
      "https://rickandmortyapi.com/api/episode/38",
      "https://rickandmortyapi.com/api/episode/39",
      "https://rickandmortyapi.com/api/episode/40",
      "https://rickandmortyapi.com/api/episode/41",
      "https://rickandmortyapi.com/api/episode/42",
      "https://rickandmortyapi.com/api/episode/43",
      "https://rickandmortyapi.com/api/episode/44",
      "https://rickandmortyapi.com/api/episode/45",
      "https://rickandmortyapi.com/api/episode/46",
      "https://rickandmortyapi.com/api/episode/47",
      "https://rickandmortyapi.com/api/episode/48",
      "https://rickandmortyapi.com/api/episode/49",
      "https://rickandmortyapi.com/api/episode/50",
      "https://rickandmortyapi.com/api/episode/51"
    ],
    "url": "https://rickandmortyapi.com/api/character/1",
    "created": "2017-11-04T18:48:46.250Z"
}

console.log(personaje1.episode.length);
console.log(personaje2.episode.length);


if (personaje1.episode.length> personaje2.episode.length){
    console.log("el nombre de personaje que tiene mas capitulos es ", personaje1.name);
    console.log("Tiene un total de" , personaje1.episode.length , "episodios");
}

  if (personaje2.episode.length > personaje1.episode.length ){
    console.log("el nombre de personaje que tiene mas capitulos es ", personaje2.name);
    console.log("Tiene un total de", personaje2.episode.length , "episodios");
 }

