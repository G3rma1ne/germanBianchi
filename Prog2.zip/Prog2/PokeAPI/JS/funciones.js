/*async function getPersonaje(){
    const response = await fetch ("https://pokeapi.co/api/v2/pokemon/flareon")
    const data = await response.json()
    console.log(data)
}
getPersonaje()
*/


async function getAll(){
    const response = await fetch ("https://pokeapi.co/api/v2/pokemon/?limit=1500")
    const data = await response.json()
    let attackSup = 0;
    console.log(data)
    /*
    for (counter1 = 0, counter1 < 1301, counter1++){
        if (attack > attackSup) {
            attacksup = attack;
        }
    }
    */
}
getAll()
